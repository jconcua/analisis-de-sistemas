﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace The_GymBro_s
{
    public partial class PrincipalMenu : Form
    {
        public PrincipalMenu()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            // Ejecuta el formulario 1
            SanJosePinula formulario = new SanJosePinula();
            //cierra el presente formulario de operaciones
            this.Hide();
            //Muestra el fomulario 1
            formulario.Show();
            formulario.StartPosition = FormStartPosition.CenterParent;

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnConsultas_Click(object sender, EventArgs e)
        {
            // Ejecuta el formulario 
            Consultas formulario = new Consultas();
            //cierra el presente formulario de operaciones
            this.Hide();
            //Muestra el fomulario 1
            formulario.Show();
            formulario.StartPosition = FormStartPosition.CenterParent;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            // Ejecuta el formulario 1
            Fraijanes formulario = new Fraijanes();
            //cierra el presente formulario de operaciones
            this.Hide();
            //Muestra el fomulario 1
            formulario.Show();
            formulario.StartPosition = FormStartPosition.CenterParent;

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            // Ejecuta el formulario 1
            SntaCatarinaPinula formulario = new SntaCatarinaPinula();
            //cierra el presente formulario de operaciones
            this.Hide();
            //Muestra el fomulario 1
            formulario.Show();
            formulario.StartPosition = FormStartPosition.CenterParent;
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            // Ejecuta el formulario 1
            SnMiguelPetapa formulario = new SnMiguelPetapa();
            //cierra el presente formulario de operaciones
            this.Hide();
            //Muestra el fomulario 1
            formulario.Show();
            formulario.StartPosition = FormStartPosition.CenterParent;
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            // Ejecuta el formulario 1
            SnJoseDelGolfo formulario = new SnJoseDelGolfo();
            //cierra el presente formulario de operaciones
            this.Hide();
            //Muestra el fomulario 1
            formulario.Show();
            formulario.StartPosition = FormStartPosition.CenterParent;
        }
    }
}
