﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.Sql;

  
namespace The_GymBro_s
{

    public partial class Registro : Form
    {

        private int? DPI;
        public Registro(int? DPI=null)
        {
            InitializeComponent();
            this.DPI = DPI;   
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            // Ejecuta el formulario 1
            PrincipalMenu formulario = new PrincipalMenu();
            //cierra el presente formulario de operaciones
            this.Hide();
            //Muestra el fomulario 1
            formulario.Show();
            formulario.StartPosition = FormStartPosition.CenterParent;
        }

        private void button1_Click(object sender, EventArgs e)
        {

           DataSet1TableAdapters.ClienteTableAdapter  ta = new DataSet1TableAdapters.ClienteTableAdapter();

            if (DPI == null)
            {

                ta.Add(System.Convert.ToInt32(txtDPI.Text.Trim()),
                    txtNombres.Text.Trim(),
                    txtCorreo.Text.Trim(),
                    txtGenero.Text.Trim(),
                    txtDireccion.Text.Trim(),
                    System.Convert.ToInt32(txtTelefono.Text.Trim()),
                    txtFechaNac.Text.Trim()
                    );

                MessageBox.Show("Registro realizado con éxito");


                PrincipalMenu formulario = new PrincipalMenu();
                this.Hide();
                formulario.Show();
                formulario.StartPosition = FormStartPosition.CenterParent;

            }

           // else
           // {
               // ta.Edit(
                   // Int32.Parse(txtDPI.Text),
                  //  txtNombres.Text.Trim(),
                  //  txtCorreo.Text.Trim(),
                  //  txtGenero.Text.Trim(),
                  //  txtDireccion.Text.Trim(),
                  //  System.Convert.ToInt32(txtTelefono.Text.Trim()),
                 //   txtFechaNac.Text.Trim(),
                 //   (int)DPI
                  //  );
            //}

        }
   

        private void RegistroSanJosePinula_Load(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }
    }
}
