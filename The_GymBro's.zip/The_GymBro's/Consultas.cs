﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace The_GymBro_s
{
    public partial class Consultas : Form
    {
        public Consultas()
        {
            InitializeComponent();
            Refresh();
        }

        private void btnRefrescar_Click(object sender, EventArgs e)
        {
            Refresh();
        }

        private void Refresh()
        {

            DataSet1TableAdapters.ClienteTableAdapter ta = new DataSet1TableAdapters.ClienteTableAdapter();
            DataSet1.ClienteDataTable dt = ta.GetData();
            dataGridView1.DataSource = dt;

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            // Ejecuta el formulario 1
            PrincipalMenu formulario = new PrincipalMenu();
            //cierra el presente formulario de operaciones
            this.Hide();
            //Muestra el fomulario 1
            formulario.Show();
            formulario.StartPosition = FormStartPosition.CenterParent;
        }

        private void Consultas_Load(object sender, EventArgs e)
        {

        }

        private int? GetId()
        {
            try
            {
                return int.Parse(

                    dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[0].Value.ToString()

                    );
            }
            catch
            {
                return null;   
            }

        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            int? DPI = GetId();


        }
    }
}
